import React, { useState } from 'react'
import './Counter.css'

 const Counter = () => {

    const [count,setCount] = useState(0)
    const handleIncrement = () => setCount(count + 1)
    const handleDecrement = () => setCount(count - 1)


  return (
    <div className='counter-container'>
    <h1  className='counter-display'>
        Counter:{count}
    </h1>
    <div className='button-container'>
    <button onClick={handleIncrement} className='counter-button'>
        increment
    </button>
    <button onClick={handleDecrement} className='counter-button'>
        decrement
    </button>
    </div>
    </div>
  )
}

export default Counter
